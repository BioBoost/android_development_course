package be.vives.android.examples.nico.pantiltexample;

/**
 * Created by Nico De Witte on 12/7/2015.
 */
public interface OrientationChangeListener {
    void onOrientationChanged(float pitch, float roll);
}
